local _, ns = ...
local L = ns.L
local Util = ns.Util

-- Post-run summary: after a Mythic+ run completes, compare the player's
-- overall score before/after the run and announce the score gain plus the
-- estimated rank improvement (this run only, not the daily delta) in party.

local run = {
    active = false,
    startedAt = 0,
    scoreBefore = nil,
    mapID = nil,
}

local function GetNow()
    if type(GetTime) == "function" then
        local ok, value = pcall(GetTime)
        if ok and type(value) == "number" then
            return value
        end
    end
    return 0
end

local function ReadPlayerScore()
    local API = _G.QFXMythicRankData
    if type(API) ~= "table" or type(API.GetPlayerScore) ~= "function" then
        return nil
    end
    local ok, score = pcall(API.GetPlayerScore, API)
    if not ok then
        return nil
    end
    return Util.SafeNumber(score)
end

local function EstimateRankForScore(region, score)
    local API = _G.QFXMythicRankData
    if type(API) ~= "table"
        or type(API.EstimateRank) ~= "function"
        or type(region) ~= "string"
        or not score
    then
        return nil
    end
    local ok, raw = pcall(API.EstimateRank, API, region, score, "all")
    local result = ok and Util.SafeTable(raw) or nil
    local rank = result and Util.SafeNumber(result.estimatedRank) or nil
    if not rank and type(Util.EstimateRankBelowTop40) == "function" then
        local okExt, extended = pcall(Util.EstimateRankBelowTop40, API, region, score, "all")
        rank = okExt and Util.SafeNumber(extended and extended.estimatedRank) or nil
    end
    return rank
end

local function FormatScoreValue(value)
    if type(value) ~= "number" then
        return "?"
    end
    local rounded = math.floor(value * 10 + 0.5) / 10
    if rounded == math.floor(rounded) then
        return tostring(math.floor(rounded))
    end
    return string.format("%.1f", rounded)
end

local function FormatRankValue(value)
    if type(value) ~= "number" then
        return "?"
    end
    return tostring(math.floor(value + 0.5))
end

local function GetRegionLabel()
    local region = ns.GetSelectedRegion()
    if not region then
        return nil
    end
    local labelKey = "RUN_REGION_LABEL_" .. string.upper(tostring(region))
    local localized = type(L) == "table" and L[labelKey] or nil
    if type(localized) == "string" and localized ~= "" then
        return localized
    end
    if type(ns.GetRegionLabel) == "function" then
        local fallback = ns.GetRegionLabel(region)
        if type(fallback) == "string" and fallback ~= "" then
            return fallback
        end
    end
    return string.upper(tostring(region))
end

local function AnnounceRunGain(scoreBefore, scoreAfter)
    if type(ns.IsRunGainAnnouncementEnabled) == "function"
        and not ns.IsRunGainAnnouncementEnabled()
    then
        return
    end
    if type(IsInGroup) == "function" then
        local ok, grouped = pcall(IsInGroup, LE_PARTY_CATEGORY_HOME or 1)
        if not ok or not grouped then
            return
        end
    end
    local region = ns.GetSelectedRegion()
    local regionLabel = GetRegionLabel()
    if not region or not regionLabel then
        return
    end
    local rankBefore = EstimateRankForScore(region, scoreBefore)
    local rankAfter = EstimateRankForScore(region, scoreAfter)
    if not rankBefore or not rankAfter then
        return
    end
    local scoreGain = scoreAfter - scoreBefore
    if scoreGain <= 0 then
        return
    end
    local rankGain = math.max(0, math.floor(rankBefore - rankAfter + 0.5))
    local formatText = L.RUN_GAIN_ANNOUNCEMENT_FORMAT
    if type(formatText) ~= "string" or formatText == "" then
        return
    end
    local okMsg, message = pcall(
        string.format,
        formatText,
        FormatScoreValue(scoreGain),
        FormatRankValue(rankGain),
        regionLabel,
        FormatRankValue(rankAfter)
    )
    if not okMsg or type(message) ~= "string" or message == "" then
        return
    end
    if type(SendChatMessage) == "function" then
        pcall(SendChatMessage, message, "PARTY")
    end
end

local function SchedulePostRunCheck()
    if not run.active then
        return
    end
    local scoreBefore = run.scoreBefore
    run.active = false
    if not scoreBefore then
        return
    end

    local attempts = 0
    local function CheckScoreUpdated()
        local scoreAfter = ReadPlayerScore()
        if scoreAfter and scoreAfter > scoreBefore + 0.05 then
            AnnounceRunGain(scoreBefore, scoreAfter)
            return
        end
        -- Blizzard refreshes map scores a moment after the completion event;
        -- retry briefly, then give up silently (e.g. no score gain because a
        -- lower-level replay did not beat the previous best).
        attempts = attempts + 1
        if attempts < 4 and C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(2, CheckScoreUpdated)
        end
    end

    if C_Timer and type(C_Timer.After) == "function" then
        C_Timer.After(2, CheckScoreUpdated)
    else
        CheckScoreUpdated()
    end
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("CHALLENGE_MODE_START")
eventFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")
eventFrame:SetScript("OnEvent", function(_, event)
    if event == "CHALLENGE_MODE_START" then
        run.active = true
        run.startedAt = GetNow()
        run.scoreBefore = ReadPlayerScore()
        run.mapID = nil
        if C_ChallengeMode and type(C_ChallengeMode.GetActiveChallengeModeID) == "function" then
            local ok, mapID = pcall(C_ChallengeMode.GetActiveChallengeModeID)
            run.mapID = ok and Util.SafeNumber(mapID) or nil
        end
    elseif event == "CHALLENGE_MODE_COMPLETED" then
        SchedulePostRunCheck()
    end
end)

-- Exposed for tests and diagnostics only.
ns.RunSummary = {
    AnnounceRunGain = AnnounceRunGain,
    EstimateRankForScore = EstimateRankForScore,
    ReadPlayerScore = ReadPlayerScore,
}
