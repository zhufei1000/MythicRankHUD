local ADDON_NAME, ns = ...
local L = ns.L
local Util = ns.Util
local RankTarget = ns.RankTarget

local DEFAULT_ROW_VISIBILITY = {
    dataUpdated = true,
    cutoff01 = true,
    cutoff1 = true,
    score = true,
    todayScore = true,
    rank = true,
    surpassed = true,
    todayRank = true,
    toTop25 = true,
    rankRange = false,
    percentileRange = false,
}

local CEREMONY_DEFAULT_X = 0
local CEREMONY_DEFAULT_Y = 274.444395477572

local DEFAULTS = {
    showHUD = true,
    announceTeleport = false,
    announceRunGain = true,
    announceMemberJoin = true,
    announceDelay = 5,
    announceMode = "auto",
    announceTexts = {},
    ceremony = { enabled = true, sound = true, scale = 1, x = CEREMONY_DEFAULT_X, y = CEREMONY_DEFAULT_Y, duration = 10 },
    enableMythicDetail = true,
    appearance = "auto",
    borderStyle = "gold",
    borderAlpha = 0.85,
    backgroundAlpha = 0.88,
    detailBorderAlpha = 1.00,
    detailBackgroundAlpha = 0.90,
    detailPoint = "CENTER",
    detailRelativePoint = "CENTER",
    detailX = 0,
    detailY = 0,
    showRows = DEFAULT_ROW_VISIBILITY,
    characters = {},
    selectedRegion = nil,
}

function ns.GetCeremonyDefaultPosition()
    return CEREMONY_DEFAULT_X, CEREMONY_DEFAULT_Y
end

local ROW_ORDER = {
    "dataUpdated",
    "cutoff01",
    "cutoff1",
    "score",
    "rank",
    "surpassed",
    "todayScore",
    "todayRank",
    "toTop25",
    "rankRange",
    "percentileRange",
}

local VALID_ANCHOR_POINTS = {
    TOPLEFT = true,
    TOP = true,
    TOPRIGHT = true,
    LEFT = true,
    CENTER = true,
    RIGHT = true,
    BOTTOMLEFT = true,
    BOTTOM = true,
    BOTTOMRIGHT = true,
}

local rows = {}
for _, key in ipairs(ROW_ORDER) do
    rows[key] = { key = key }
end
local hudSnapshot = {}
local hudSnapshotSignature
local db
local characterDB
local databaseInitialized = false
local englishTextWarningPrinted = false
local CLIENT_LOCALE = type(GetLocale) == "function" and GetLocale() or nil
local DB_GLOBAL_NAME = ADDON_NAME == "QFXMythicRankHUD" and "QFXMythicRankHUDDB"
    or "QFXMythicRankHUDGlobalDB"
local CHAR_DB_GLOBAL_NAME = ADDON_NAME == "QFXMythicRankHUD" and "QFXMythicRankHUDCharDB"
    or "QFXMythicRankHUDGlobalCharDB"
local GOLD_R, GOLD_G, GOLD_B = 1.0, 0.82, 0.0

local function CopyDefaults(target, defaults)
    if type(target) ~= "table" then
        target = {}
    end
    for key, value in pairs(defaults) do
        if type(value) == "table" then
            target[key] = CopyDefaults(target[key], value)
        elseif target[key] == nil then
            target[key] = value
        end
    end
    return target
end

local function InitializeDatabase()
    if databaseInitialized then
        return db
    end

    local existingGlobal = _G[DB_GLOBAL_NAME]
    local oldDB = type(existingGlobal) == "table" and existingGlobal or nil
    local hadShowRows = oldDB and type(oldDB.showRows) == "table"
    local oldShowRanges = oldDB and oldDB.showRanges
    local hadDetailBorderAlpha = oldDB and oldDB.detailBorderAlpha ~= nil
    local hadDetailBackgroundAlpha = oldDB and oldDB.detailBackgroundAlpha ~= nil
    local legacyBorderAlpha = oldDB and oldDB.borderAlpha or nil
    local legacyBackgroundAlpha = oldDB and oldDB.backgroundAlpha or nil

    local globalDB = CopyDefaults(oldDB, DEFAULTS)
    _G[DB_GLOBAL_NAME] = globalDB

    if not hadShowRows and oldShowRanges == true then
        globalDB.showRows.rankRange = true
        globalDB.showRows.percentileRange = true
    end

    db = globalDB
    db.showRanges = nil

    if type(db.showHUD) ~= "boolean" then
        db.showHUD = DEFAULTS.showHUD
    end
    if type(db.announceTeleport) ~= "boolean" then
        db.announceTeleport = DEFAULTS.announceTeleport
    end
    if type(db.announceRunGain) ~= "boolean" then
        db.announceRunGain = DEFAULTS.announceRunGain
    end
    if type(db.announceMemberJoin) ~= "boolean" then
        db.announceMemberJoin = DEFAULTS.announceMemberJoin
    end
    db.announceDelay = Util.ClampNumber(db.announceDelay, 0, 60, DEFAULTS.announceDelay)
    if type(db.announceTexts) ~= "table" then
        db.announceTexts = {}
    end
    -- Older builds persisted the built-in template text as an override when a
    -- settings box lost focus without edits; drop those so future default-text
    -- updates take effect. RUN_MEMBER_LINE also had an older default wording.
    local LEGACY_ANNOUNCE_TEMPLATES = {
        RUN_MEMBER_LINE = {
            "{name}: score <{score}> (+{scoreGain}) | {region} rank <~{rank}> (up <~{rankGain}>)",
            "{name}：当前<{score}>分，本次提升<{scoreGain}>分；{region}排名<~{rank}>名，本次提升<~{rankGain}>名",
        },
        -- Bare "|" separators made the 12.x chat API reject these with
        -- "Invalid escape code in chat message"; the defaults no longer use
        -- pipes, so drop overrides that still match the old wording.
        MEMBER_WELCOME_FORMAT = {
            "Met {meetCount}x this month | {name} | M+ score: {score} | {region} rank ~{rank}. Welcome aboard, good luck!",
            "{name}，本月第{meetCount}次遇到 | 现大秘境分数：{score}，{region}排名约 {rank} 名。欢迎加入，一起加油吧！",
            "{name}，本月第{meetCount}次遇到 | 現大秘境分數：{score}，{region}排名約 {rank} 名。歡迎加入，一起加油吧！",
        },
        MEMBER_WELCOME_AGAIN_FORMAT = {
            "{name} | met {meetCount}x this month | {scoreChangeText} | last met: {lastMeetTime}",
        },
    }
    for key, value in pairs(db.announceTexts) do
        local stale = value == L[key]
        local legacy = LEGACY_ANNOUNCE_TEMPLATES[key]
        if not stale and type(legacy) == "table" then
            for _, legacyText in ipairs(legacy) do
                if value == legacyText then
                    stale = true
                    break
                end
            end
        end
        if stale then
            db.announceTexts[key] = nil
        end
    end
    if type(db.enableMythicDetail) ~= "boolean" then
        db.enableMythicDetail = DEFAULTS.enableMythicDetail
    end
    db.borderAlpha = Util.ClampNumber(db.borderAlpha, 0, 1, DEFAULTS.borderAlpha)
    db.backgroundAlpha = Util.ClampNumber(db.backgroundAlpha, 0, 1, DEFAULTS.backgroundAlpha)
    if not hadDetailBorderAlpha and oldDB then
        db.detailBorderAlpha = Util.ClampNumber(legacyBorderAlpha, 0, 1, DEFAULTS.detailBorderAlpha)
    else
        db.detailBorderAlpha = Util.ClampNumber(db.detailBorderAlpha, 0, 1, DEFAULTS.detailBorderAlpha)
    end
    if not hadDetailBackgroundAlpha and oldDB then
        db.detailBackgroundAlpha = Util.ClampNumber(
            legacyBackgroundAlpha,
            0,
            1,
            DEFAULTS.detailBackgroundAlpha
        )
    else
        db.detailBackgroundAlpha = Util.ClampNumber(
            db.detailBackgroundAlpha,
            0,
            1,
            DEFAULTS.detailBackgroundAlpha
        )
    end
    if db.borderStyle ~= "transparent" and db.borderStyle ~= "class" and db.borderStyle ~= "gold" then
        db.borderStyle = DEFAULTS.borderStyle
    end
    if db.appearance ~= "addon" and db.appearance ~= "blizzard" and db.appearance ~= "classic" then
        db.appearance = DEFAULTS.appearance
    end
    db.detailPoint = VALID_ANCHOR_POINTS[db.detailPoint] and db.detailPoint or DEFAULTS.detailPoint
    db.detailRelativePoint = VALID_ANCHOR_POINTS[db.detailRelativePoint]
        and db.detailRelativePoint
        or DEFAULTS.detailRelativePoint
    db.detailX = Util.ClampNumber(db.detailX, -100000, 100000, DEFAULTS.detailX)
    db.detailY = Util.ClampNumber(db.detailY, -100000, 100000, DEFAULTS.detailY)

    for _, key in ipairs(ROW_ORDER) do
        if type(db.showRows[key]) ~= "boolean" then
            db.showRows[key] = DEFAULT_ROW_VISIBILITY[key]
        end
    end

    -- Encounter history is stored per character, not per account.
    local existingCharacter = _G[CHAR_DB_GLOBAL_NAME]
    characterDB = type(existingCharacter) == "table" and existingCharacter or {}
    _G[CHAR_DB_GLOBAL_NAME] = characterDB
    if type(characterDB.encounters) ~= "table" then
        characterDB.encounters = {}
    end
    -- One-time migration: the encounter table used to live in the
    -- account-wide database.
    if type(globalDB.encounters) == "table" then
        for guid, record in pairs(globalDB.encounters) do
            if characterDB.encounters[guid] == nil then
                characterDB.encounters[guid] = record
            end
        end
        globalDB.encounters = nil
    end

    databaseInitialized = true
    return db
end

local function GetDB()
    return db or InitializeDatabase()
end

function ns.GetCharacterDB()
    GetDB()
    return characterDB
end

local function GetCharacterKey()
    local guid = UnitGUID("player")
    if guid then
        return guid
    end
    local name, realm = UnitFullName("player")
    if not name then
        return "unknown"
    end
    return name .. "-" .. (realm or GetRealmName() or "")
end

function ns.GetCharacterKey()
    return GetCharacterKey()
end

local function GetDateKey()
    if C_DateAndTime and type(C_DateAndTime.GetCurrentCalendarTime) == "function" then
        local calendar = C_DateAndTime.GetCurrentCalendarTime()
        if calendar and calendar.year and calendar.month and calendar.monthDay then
            return string.format("%04d%02d%02d", calendar.year, calendar.month, calendar.monthDay)
        end
    end
    if type(date) == "function" then
        return date("%Y%m%d")
    end
    return "unknown"
end

local function FormatVersionTimestamp(version)
    local text = tostring(version or "")
    -- Show the data pack's region-local wall clock, matching the run
    -- announcements; the raw UTC string stays as the fallback while the
    -- summary module or the selected region is unavailable.
    local summary = ns.RunSummary
    local formatLocal = summary and summary.FormatDataVersionLocal
    local region = type(ns.GetSelectedRegion) == "function" and ns.GetSelectedRegion() or nil
    if type(formatLocal) == "function" and region then
        local ok, localized = pcall(formatLocal, text, region)
        if ok and type(localized) == "string" and localized ~= "" then
            return localized
        end
    end
    local year, month, day, hour, minute = text:match(
        "^(%d%d%d%d)(%d%d)(%d%d)(%d%d)(%d%d)"
    )
    if not year then return "--" end
    return string.format(
        L.DATA_TIME_FORMAT,
        tonumber(month),
        tonumber(day),
        tonumber(hour),
        tonumber(minute)
    )
end

local function GetDataUpdatedTime(metadata)
    local sourceTime = FormatVersionTimestamp(metadata and metadata.dataVersion)
    return string.format(L.DATA_UPDATED, sourceTime)
end

local function FormatScore(value, decimals)
    if type(value) ~= "number" then
        return "--"
    end
    return string.format("%." .. tostring(decimals or 1) .. "f", value)
end

local function FormatInteger(value)
    if type(value) ~= "number" then
        return "--"
    end
    return tostring(math.floor(value + 0.5))
end

local function FormatCompactRank(value)
    if type(value) ~= "number" then
        return "--"
    end
    if CLIENT_LOCALE == "zhCN" or CLIENT_LOCALE == "zhTW" then
        if value >= 10000 then
            return string.format("%.1f万", value / 10000)
        end
        return FormatInteger(value)
    end
    if value >= 1000000 then
        return string.format("%.2fM", value / 1000000)
    end
    return FormatInteger(value)
end

local function FormatPercent(value)
    if type(value) ~= "number" then
        return "--"
    end
    if math.abs(value - math.floor(value + 0.5)) < 0.005 then
        return tostring(math.floor(value + 0.5))
    end
    return string.format("%.1f", value)
end

local function HexToRGB(hex)
    if type(hex) ~= "string" then
        return GOLD_R, GOLD_G, GOLD_B
    end
    hex = hex:gsub("#", "")
    if #hex ~= 6 then
        return GOLD_R, GOLD_G, GOLD_B
    end
    local r = tonumber(hex:sub(1, 2), 16)
    local g = tonumber(hex:sub(3, 4), 16)
    local b = tonumber(hex:sub(5, 6), 16)
    if not r or not g or not b then
        return GOLD_R, GOLD_G, GOLD_B
    end
    return r / 255, g / 255, b / 255
end

local function SetRow(row, label, value, r, g, b)
    if row.label and row.value then
        row.label:SetText(label)
        row.value:SetText(value)
        row.value:SetTextColor(r or 1, g or 1, b or 1)
    end
    if row.key then
        local snapshot = hudSnapshot[row.key] or {}
        snapshot.label = label
        snapshot.value = value
        snapshot.r = r or 1
        snapshot.g = g or 1
        snapshot.b = b or 1
        hudSnapshot[row.key] = snapshot
    end
end

local function GetClassColor()
    local _, classToken = UnitClass("player")
    local color = classToken and CUSTOM_CLASS_COLORS and CUSTOM_CLASS_COLORS[classToken]
    if not color then
        color = classToken and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classToken]
    end
    if color then
        return color.r or GOLD_R, color.g or GOLD_G, color.b or GOLD_B
    end
    return GOLD_R, GOLD_G, GOLD_B
end

local function GetAccentColor(alpha)
    local db = GetDB()
    local r, g, b = 0.72, 0.56, 0.18
    if db.borderStyle == "class" then
        r, g, b = GetClassColor()
    elseif db.borderStyle == "transparent" then
        return r, g, b, 0
    end
    return r, g, b, alpha
end

local function GetHUDAccentColor()
    local db = GetDB()
    return GetAccentColor(db.borderAlpha)
end

local function GetDetailAccentColor()
    local db = GetDB()
    return GetAccentColor(db.detailBorderAlpha)
end

local function UpdateDailyState(score)
    local db = GetDB()
    local key = GetCharacterKey()
    local state = db.characters[key]
    if type(state) ~= "table" then
        state = {}
        db.characters[key] = state
    end

    local today = GetDateKey()
    if state.dateKey ~= today then
        state.dateKey = today
        state.baselineScore = tonumber(state.lastScore) or score
    elseif type(state.baselineScore) ~= "number" then
        state.baselineScore = score
    end

    state.lastScore = score
    return state
end

local function UpdateDailyScoreStateOnly()
    local API = _G.QFXMythicRankData
    if type(API) ~= "table" or type(API.GetPlayerScore) ~= "function" then
        return
    end

    local score = Util.SafeNumber(API:GetPlayerScore())
    if score == nil then
        return
    end

    UpdateDailyState(score)
end

local function SetUnavailable(message)
    hudSnapshotSignature = nil
    local unavailable = message or L.UNAVAILABLE
    local regionLabel = ns.GetSelectedRegionLabel()
    local rankLabel = regionLabel and string.format(L.REGION_RANK_FORMAT, regionLabel)
        or L.SETTINGS_ROW_REGION_RANK
    SetRow(rows.dataUpdated, "", string.format(L.DATA_UPDATED, unavailable), GOLD_R, GOLD_G, GOLD_B)
    SetRow(rows.cutoff01, L.CUTOFF_01, unavailable, 0.65, 0.65, 0.65)
    SetRow(rows.cutoff1, L.CUTOFF_1, unavailable, 0.65, 0.65, 0.65)
    SetRow(rows.score, L.SCORE, unavailable, 0.65, 0.65, 0.65)
    SetRow(rows.todayScore, L.TODAY_SCORE, "--", 0.65, 0.65, 0.65)
    SetRow(rows.rank, rankLabel, "--", 0.65, 0.65, 0.65)
    SetRow(rows.surpassed, L.SURPASSED, "--", 0.65, 0.65, 0.65)
    SetRow(rows.todayRank, L.TODAY_RANK, "--", 0.65, 0.65, 0.65)
    SetRow(rows.toTop25, L.SMART_NEXT_TARGET, "--", 0.65, 0.65, 0.65)
    SetRow(rows.rankRange, L.RANK_RANGE, "--", 0.65, 0.65, 0.65)
    SetRow(rows.percentileRange, L.PERCENTILE_RANGE, "--", 0.65, 0.65, 0.65)
end

local function GetHUDAchievementTargets(API, region)
    if type(API.GetAchievementCutoff) ~= "function" then
        return nil
    end
    local definitions = {
        { key = "keystoneExplorer", name = L.ACHIEVEMENT_KEYSTONE_EXPLORER_SHORT },
        { key = "keystoneConqueror", name = L.ACHIEVEMENT_KEYSTONE_CONQUEROR_SHORT },
        { key = "keystoneMaster", name = L.ACHIEVEMENT_KEYSTONE_MASTER_SHORT },
        { key = "keystoneHero", name = L.ACHIEVEMENT_KEYSTONE_HERO_SHORT },
        { key = "keystoneLegend", name = L.ACHIEVEMENT_KEYSTONE_LEGEND_SHORT },
    }
    local targets = {}
    for _, definition in ipairs(definitions) do
        local ok, raw = pcall(API.GetAchievementCutoff, API, region, definition.key)
        if not ok or raw == nil then
            -- Older regional data packs exposed the key without a region
            -- argument; keep working with them.
            ok, raw = pcall(API.GetAchievementCutoff, API, definition.key)
        end
        local value = Util.SafeTable(raw)
        local threshold = Util.SafeNumber(value and (value.thresholdScore or value.score) or raw)
        if threshold then
            targets[#targets + 1] = {
                key = definition.key,
                thresholdScore = threshold,
                localizedName = definition.name,
                color = value and Util.SafeString(value.color) or nil,
            }
        end
    end
    return targets
end

local function GetAPICapabilityMask(API)
    if type(API) ~= "table" then
        return "0"
    end
    local mask = 0
    if type(API.GetMetadata) == "function" then mask = mask + 1 end
    if type(API.GetCutoff) == "function" then mask = mask + 2 end
    if type(API.GetPlayerScore) == "function" then mask = mask + 4 end
    if type(API.EstimateRank) == "function" then mask = mask + 8 end
    if type(API.EstimatePlayerRank) == "function" then mask = mask + 16 end
    return tostring(mask)
end

local function RefreshHUDData(force)

    local API = _G.QFXMythicRankData
    local region = ns.GetSelectedRegion()
    local regionLabel = ns.GetSelectedRegionLabel()
    local rankLabel = regionLabel and string.format(L.REGION_RANK_FORMAT, regionLabel)
        or L.SETTINGS_ROW_REGION_RANK
    if type(API) ~= "table"
        or type(API.GetMetadata) ~= "function"
        or type(API.GetCutoff) ~= "function"
        or type(API.GetPlayerScore) ~= "function"
        or type(API.EstimateRank) ~= "function"
        or not region
    then
        SetUnavailable()
        return
    end

    local metadata = Util.SafeTable(API:GetMetadata(region))
    local cutoffByKey = {}
    for _, definition in ipairs(RankTarget.CUTOFF_DEFS) do
        cutoffByKey[definition.key] = Util.SafeTable(API:GetCutoff(region, definition.key, "all"))
    end
    local cutoff01 = cutoffByKey.p999
    local cutoff1 = cutoffByKey.p990
    local cutoff10 = cutoffByKey.p900
    local cutoff25 = cutoffByKey.p750
    local cutoff40 = cutoffByKey.p600
    local score = Util.SafeNumber(API:GetPlayerScore())

    local cutoff01Score = cutoff01 and Util.SafeNumber(cutoff01.score)
    local cutoff1Score = cutoff1 and Util.SafeNumber(cutoff1.score)
    local cutoff10Score = cutoff10 and Util.SafeNumber(cutoff10.score)
    local cutoff25Score = cutoff25 and Util.SafeNumber(cutoff25.score)
    local cutoff40Score = cutoff40 and Util.SafeNumber(cutoff40.score)
    if not metadata
        or not cutoff01Score
        or not cutoff1Score
        or not cutoff10Score
        or not cutoff25Score
        or not cutoff40Score
    then
        SetUnavailable()
        return
    end

    -- The rows only change when the region, the data pack, the player's score,
    -- the daily baseline or the cutoffs change; the heavy estimate work below
    -- is skipped while the snapshot still matches this signature.
    local signature = table.concat({
        region,
        GetAPICapabilityMask(API),
        score ~= nil and tostring(score) or "nil",
        Util.SafeString(metadata.dataVersion) or "",
        tostring(Util.SafeNumber(metadata.population) or ""),
        tostring(cutoff01Score),
        tostring(cutoff1Score),
        tostring(cutoff10Score),
        tostring(cutoff25Score),
        tostring(cutoff40Score),
        GetDateKey(),
    }, "|")
    if not force and signature == hudSnapshotSignature then
        return
    end
    hudSnapshotSignature = signature

    local c01r, c01g, c01b = HexToRGB(cutoff01.color)
    local c1r, c1g, c1b = HexToRGB(cutoff1.color)
    SetRow(rows.dataUpdated, "", GetDataUpdatedTime(metadata), GOLD_R, GOLD_G, GOLD_B)
    SetRow(rows.cutoff01, L.CUTOFF_01, FormatScore(cutoff01Score, 1), c01r, c01g, c01b)
    SetRow(rows.cutoff1, L.CUTOFF_1, FormatScore(cutoff1Score, 1), c1r, c1g, c1b)

    if type(score) ~= "number" then
        SetRow(rows.score, L.SCORE, L.NO_SCORE, 0.65, 0.65, 0.65)
        SetRow(rows.todayScore, L.TODAY_SCORE, "--", 0.65, 0.65, 0.65)
        SetRow(rows.rank, rankLabel, "--", 0.65, 0.65, 0.65)
        SetRow(rows.surpassed, L.SURPASSED, "--", 0.65, 0.65, 0.65)
        SetRow(rows.todayRank, L.TODAY_RANK, "--", 0.65, 0.65, 0.65)
        SetRow(rows.toTop25, L.SMART_NEXT_TARGET, "--", 0.65, 0.65, 0.65)
        SetRow(rows.rankRange, L.RANK_RANGE, "--", 0.65, 0.65, 0.65)
        SetRow(rows.percentileRange, L.PERCENTILE_RANGE, "--", 0.65, 0.65, 0.65)
        return
    end

    local result = type(API.EstimatePlayerRank) == "function"
        and Util.SafeTable(API:EstimatePlayerRank(region, "all"))
        or Util.SafeTable(API:EstimateRank(region, score, "all"))
    if not result then
        SetUnavailable()
        return
    end

    local state = UpdateDailyState(score)
    local baselineScore = tonumber(state.baselineScore) or score
    local baselineResult = Util.SafeTable(API:EstimateRank(region, baselineScore, "all"))
    local scoreGain = score - baselineScore
    local estimatedRank = Util.SafeNumber(result.estimatedRank)
    local rankMin = Util.SafeNumber(result.rankMin)
    local rankMax = Util.SafeNumber(result.rankMax)
    local rankUncertainty = Util.SafeNumber(result.rankUncertainty)
    local percentileMin = Util.SafeNumber(result.percentileMin)
    local percentileMax = Util.SafeNumber(result.percentileMax)
    local extendedEstimate
    if not estimatedRank then
        extendedEstimate = Util.EstimateRankBelowTop40(API, region, score, "all")
        if extendedEstimate then
            estimatedRank = Util.SafeNumber(extendedEstimate.estimatedRank)
            rankMin = Util.SafeNumber(extendedEstimate.rankMin) or rankMin
            rankMax = Util.SafeNumber(extendedEstimate.rankMax) or rankMax
            percentileMin = Util.SafeNumber(extendedEstimate.percentileMin) or percentileMin
            percentileMax = Util.SafeNumber(extendedEstimate.percentileMax) or percentileMax
        end
    end
    local resultBracket = Util.SafeString(result.bracket)
    local baselineEstimatedRank = baselineResult and Util.SafeNumber(baselineResult.estimatedRank) or nil
    if not baselineEstimatedRank then
        local baselineExtendedEstimate = Util.EstimateRankBelowTop40(API, region, baselineScore, "all")
        baselineEstimatedRank = baselineExtendedEstimate
            and Util.SafeNumber(baselineExtendedEstimate.estimatedRank) or nil
    end
    local baselineBracket = baselineResult and Util.SafeString(baselineResult.bracket) or nil
    local hasExactTopRank = result.isExactLeaderboardRank == true
    local hasRoundedTopRank = result.isRoundedLeaderboardRank == true
    local baselineHasRoundedTopRank = baselineResult and baselineResult.isRoundedLeaderboardRank == true
    local currentTop01 = hasRoundedTopRank or score >= cutoff01Score or resultBracket == "p999"
    if hasExactTopRank or hasRoundedTopRank then
        local cutoffRank = Util.SafeNumber(cutoff01.rank)
        currentTop01 = cutoffRank and estimatedRank and estimatedRank <= cutoffRank or false
    end
    local baselineTop01 = baselineScore >= cutoff01Score
        or baselineBracket == "p999" or baselineHasRoundedTopRank
    if baselineHasRoundedTopRank then
        local cutoffRank = Util.SafeNumber(cutoff01.rank)
        baselineTop01 = cutoffRank and baselineEstimatedRank
            and baselineEstimatedRank <= cutoffRank or false
    end
    local topRankMax = rankMax or Util.SafeNumber(cutoff01.rank)
    local topPercentile = percentileMax or Util.SafeNumber(cutoff01.percentile) or 0.1

    local scoreColor = Util.GetPlayerScoreColor(API, region, score)
    local scoreR, scoreG, scoreB
    if scoreColor then
        scoreR, scoreG, scoreB = Util.HexColorToRGB(scoreColor, 1, 1, 1)
    else
        scoreR, scoreG, scoreB = 1, 1, 1
    end
    SetRow(rows.score, L.SCORE, FormatScore(score, 1), scoreR, scoreG, scoreB)

    local scoreGainText = (scoreGain >= 0 and "+" or "") .. FormatScore(scoreGain, 1)
    local gainR, gainG, gainB = 0.6, 0.85, 0.6
    if scoreGain < 0 then
        gainR, gainG, gainB = 1, 0.45, 0.45
    end
    SetRow(rows.todayScore, L.TODAY_SCORE, string.format(L.SCORE_POINTS, scoreGainText), gainR, gainG, gainB)

    if hasExactTopRank and estimatedRank then
        SetRow(rows.rank, rankLabel, string.format(L.TOP_EXACT_RANK_VALUE, FormatInteger(estimatedRank)), 1, 0.82, 0)
    elseif hasRoundedTopRank and estimatedRank then
        local value
        if rankUncertainty and rankUncertainty > 0 then
            value = string.format(L.APPROX_RANK_WITH_MARGIN,
                FormatInteger(estimatedRank), FormatInteger(rankUncertainty))
        elseif result.isRoundedTie then
            value = string.format(L.TOP_TIED_RANK_VALUE, FormatInteger(estimatedRank))
        else
            value = string.format(L.APPROX_RANK, FormatCompactRank(estimatedRank))
        end
        SetRow(rows.rank, rankLabel, value, 1, 0.82, 0)
    elseif currentTop01 and topRankMax then
        SetRow(rows.rank, rankLabel, string.format(L.TOP_RANK_VALUE, FormatInteger(topRankMax)), 1, 0.82, 0)
    elseif estimatedRank then
        SetRow(rows.rank, rankLabel, string.format(L.APPROX_RANK, FormatCompactRank(estimatedRank)), 1, 0.82, 0)
    elseif rankMin and rankMax then
        local range = string.format(L.RANGE_JOIN, FormatCompactRank(rankMin), FormatCompactRank(rankMax))
        SetRow(rows.rank, rankLabel, string.format(L.APPROX_RANK, range), 1, 0.82, 0)
    else
        SetRow(rows.rank, rankLabel, L.UNAVAILABLE, 0.65, 0.65, 0.65)
    end

    local population = Util.SafeNumber(metadata.population)
    if (hasExactTopRank or hasRoundedTopRank) and estimatedRank and population and population > 0 then
        local surpassed = math.max(0, math.min(100, 100 - (estimatedRank / population * 100)))
        SetRow(rows.surpassed, L.SURPASSED, string.format(L.APPROX, string.format("%.1f%%", surpassed)), 0.45, 0.85, 1)
    elseif currentTop01 then
        local surpassedAtLeast = math.max(0, math.min(100, 100 - topPercentile))
        SetRow(
            rows.surpassed,
            L.SURPASSED,
            string.format(L.SURPASSED_AT_LEAST, FormatPercent(surpassedAtLeast)),
            0.45,
            0.85,
            1
        )
    elseif estimatedRank and population and population > 0 then
        local surpassed = math.max(0, math.min(100, 100 - (estimatedRank / population * 100)))
        SetRow(rows.surpassed, L.SURPASSED, string.format(L.APPROX, string.format("%.1f%%", surpassed)), 0.45, 0.85, 1)
    elseif percentileMin and percentileMax then
        local low = math.max(0, 100 - percentileMax)
        local high = math.min(100, 100 - percentileMin)
        local range = string.format(L.RANGE_JOIN, string.format("%.1f%%", low), string.format("%.1f%%", high))
        SetRow(rows.surpassed, L.SURPASSED, string.format(L.APPROX, range), 0.45, 0.85, 1)
    else
        SetRow(rows.surpassed, L.SURPASSED, L.UNAVAILABLE, 0.65, 0.65, 0.65)
    end

    if hasRoundedTopRank and baselineHasRoundedTopRank and baselineEstimatedRank then
        local movement = baselineEstimatedRank - estimatedRank
        local text = string.format(L.APPROX_RANK, FormatCompactRank(math.abs(movement)))
        if movement > 0 then
            text = string.format(L.TODAY_FORWARD_VALUE, FormatCompactRank(movement))
        elseif movement < 0 then
            text = string.format(L.TODAY_BACK_VALUE, FormatCompactRank(-movement))
        end
        SetRow(rows.todayRank, L.TODAY_RANK, text, 0.82, 0.82, 0.82)
    elseif currentTop01 then
        if baselineTop01 then
            SetRow(rows.todayRank, L.TODAY_RANK, L.TODAY_WITHIN_TOP_01, 0.82, 0.82, 0.82)
        else
            SetRow(rows.todayRank, L.TODAY_RANK, L.TODAY_ENTERED_TOP_01, 0.6, 0.9, 0.6)
        end
    elseif baselineTop01 then
        SetRow(rows.todayRank, L.TODAY_RANK, L.TODAY_LEFT_TOP_01, 1, 0.45, 0.45)
    elseif estimatedRank and baselineEstimatedRank then
        local movement = baselineEstimatedRank - estimatedRank
        if movement > 0 then
            SetRow(rows.todayRank, L.TODAY_RANK, string.format(L.TODAY_FORWARD_VALUE, FormatCompactRank(movement)), 0.6, 0.85, 0.6)
        elseif movement < 0 then
            SetRow(rows.todayRank, L.TODAY_RANK, string.format(L.TODAY_BACK_VALUE, FormatCompactRank(math.abs(movement))), 1, 0.45, 0.45)
        else
            SetRow(rows.todayRank, L.TODAY_RANK, string.format(L.APPROX_RANK, FormatCompactRank(0)), 0.82, 0.82, 0.82)
        end
    else
        SetRow(rows.todayRank, L.TODAY_RANK, "--", 0.65, 0.65, 0.65)
    end

    local smartCutoffs = {}
    for index = #RankTarget.CUTOFF_DEFS, 1, -1 do
        local definition = RankTarget.CUTOFF_DEFS[index]
        local cutoff = Util.SafeTable(cutoffByKey[definition.key])
        if cutoff then
            local cutoffScore = Util.SafeNumber(cutoff.score)
            if cutoffScore then
                smartCutoffs[#smartCutoffs + 1] = {
                    key = definition.key,
                    percent = definition.percent,
                    score = cutoffScore,
                    color = Util.SafeString(cutoff.color),
                }
            end
        end
    end
    local achievementTargets = GetHUDAchievementTargets(API, region)
    local smartTarget = RankTarget.Resolve(score, smartCutoffs, achievementTargets)

    if smartTarget then
        local targetR, targetG, targetB = HexToRGB(smartTarget.color)
        local label = smartTarget.targetKind == "achievement"
            and (smartTarget.targetName or L.SMART_NEXT_TARGET)
            or string.format(L.SMART_CUTOFF_LINE_FORMAT, smartTarget.targetPercent or "0.1")
        local value
        if smartTarget.mode == "complete" then
            value = L.SMART_TARGET_REACHED
            targetR, targetG, targetB = 0.45, 0.9, 0.45
        else
            value = string.format(
                L.SMART_TARGET_DISTANCE_COMPACT,
                FormatScore(smartTarget.distance or 0, 0)
            )
        end
        SetRow(
            rows.toTop25,
            label,
            value,
            targetR,
            targetG,
            targetB
        )
    else
        SetRow(rows.toTop25, L.SMART_NEXT_TARGET, "--", 0.65, 0.65, 0.65)
    end

    if hasExactTopRank and estimatedRank then
        SetRow(rows.rankRange, L.RANK_RANGE, FormatInteger(estimatedRank), 0.82, 0.82, 0.82)
    elseif hasRoundedTopRank and rankMin and rankMax then
        local value = rankMin == rankMax and FormatInteger(rankMin)
            or string.format(L.RANGE_JOIN, FormatInteger(rankMin), FormatInteger(rankMax))
        SetRow(rows.rankRange, L.RANK_RANGE, value, 0.82, 0.82, 0.82)
    elseif currentTop01 and topRankMax then
        SetRow(
            rows.rankRange,
            L.RANK_RANGE,
            string.format(L.TOP_RANK_RANGE_VALUE, FormatInteger(topRankMax)),
            0.82,
            0.82,
            0.82
        )
    elseif rankMin and rankMax then
        local range = string.format(L.RANGE_JOIN, FormatCompactRank(rankMin), FormatCompactRank(rankMax))
        SetRow(rows.rankRange, L.RANK_RANGE, range, 0.82, 0.82, 0.82)
    else
        SetRow(rows.rankRange, L.RANK_RANGE, "--", 0.65, 0.65, 0.65)
    end

    if currentTop01 then
        SetRow(
            rows.percentileRange,
            L.PERCENTILE_RANGE,
            string.format(L.TOP_PERCENTILE_RANGE_VALUE, FormatPercent(topPercentile)),
            0.82,
            0.82,
            0.82
        )
    elseif percentileMin and percentileMax then
        local range = string.format(
            L.PERCENT_RANGE_VALUE,
            FormatPercent(percentileMin),
            FormatPercent(percentileMax)
        )
        SetRow(rows.percentileRange, L.PERCENTILE_RANGE, range, 0.82, 0.82, 0.82)
    else
        SetRow(rows.percentileRange, L.PERCENTILE_RANGE, "--", 0.65, 0.65, 0.65)
    end
end

function ns.RefreshHUDData()
    RefreshHUDData(true)
end

function ns.GetHUDSnapshot(refresh)
    if refresh ~= false then
        RefreshHUDData(false)
    end
    return hudSnapshot, GetDB().showRows
end

function ns.ApplyHUDStyle()
    if ns.RefreshMeetingStoneIntegration then
        ns.RefreshMeetingStoneIntegration("style")
    end
end

function ns.GetDB()
    return GetDB()
end

function ns.SetHUDShown(enabled)
    local currentDB = GetDB()
    currentDB.showHUD = enabled == true

    if ns.RefreshMeetingStoneIntegration then
        ns.RefreshMeetingStoneIntegration("visibility")
    end
end

function ns.IsTeleportAnnouncementEnabled()
    return GetDB().announceTeleport ~= false
end

function ns.SetTeleportAnnouncementEnabled(enabled)
    GetDB().announceTeleport = enabled == true
end

function ns.IsRunGainAnnouncementEnabled()
    return GetDB().announceRunGain ~= false
end

function ns.SetRunGainAnnouncementEnabled(enabled)
    GetDB().announceRunGain = enabled == true
    if ns.Announcer and type(ns.Announcer.Refresh) == "function" then
        ns.Announcer.Refresh(0)
    end
end

function ns.IsMemberWelcomeEnabled()
    return GetDB().announceMemberJoin ~= false
end

function ns.SetMemberWelcomeEnabled(enabled)
    GetDB().announceMemberJoin = enabled == true
    if ns.Announcer and type(ns.Announcer.Refresh) == "function" then
        ns.Announcer.Refresh(0)
    end
end

function ns.GetRunAnnounceDelay()
    return GetDB().announceDelay
end

function ns.SetRunAnnounceDelay(value)
    GetDB().announceDelay = Util.ClampNumber(value, 0, 60, DEFAULTS.announceDelay)
end

-- Announcement mode: "auto" elects a single announcer per party through the
-- Announcer module, "all" keeps the old everyone-posts behavior, "leader"
-- restricts announcements to the party leader.
function ns.GetAnnounceMode()
    local mode = GetDB().announceMode
    if mode ~= "all" and mode ~= "leader" then
        return DEFAULTS.announceMode
    end
    return mode
end

function ns.SetAnnounceMode(value)
    if value ~= "all" and value ~= "leader" then
        value = DEFAULTS.announceMode
    end
    GetDB().announceMode = value
    if ns.Announcer and type(ns.Announcer.Refresh) == "function" then
        ns.Announcer.Refresh(0)
    end
end

-- Announcement templates: an empty/nil override falls back to the locale
-- default, so clearing a settings box restores the built-in text.
function ns.GetAnnounceTemplate(key)
    local texts = GetDB().announceTexts
    if type(texts) == "table" and type(texts[key]) == "string" and texts[key] ~= "" then
        return texts[key]
    end
    return nil
end

function ns.SetAnnounceTemplate(key, text)
    local db = GetDB()
    if type(db.announceTexts) ~= "table" then
        db.announceTexts = {}
    end
    if type(text) ~= "string" or text == "" then
        db.announceTexts[key] = nil
    else
        db.announceTexts[key] = text
    end
end

function ns.ResetAnnounceTemplates()
    GetDB().announceTexts = {}
end


function ns.SetDetailEnabled(value)
    GetDB().enableMythicDetail = value == true
end

function ns.SetCeremonyEnabled(value)
    GetDB().ceremony.enabled = value == true
    if ns.Ceremony and type(ns.Ceremony.ApplySettingChange) == "function" then
        ns.Ceremony.ApplySettingChange()
    end
end

function ns.SetCeremonySound(value)
    GetDB().ceremony.sound = value == true
end

function ns.SetHUDBorderAlpha(value)
    GetDB().borderAlpha = Util.ClampNumber(value, 0, 1, DEFAULTS.borderAlpha)
end

function ns.SetHUDBackgroundAlpha(value)
    GetDB().backgroundAlpha = Util.ClampNumber(value, 0, 1, DEFAULTS.backgroundAlpha)
end

function ns.SetDetailBorderAlpha(value)
    GetDB().detailBorderAlpha = Util.ClampNumber(value, 0, 1, DEFAULTS.detailBorderAlpha)
end

function ns.SetDetailBackgroundAlpha(value)
    GetDB().detailBackgroundAlpha = Util.ClampNumber(value, 0, 1, DEFAULTS.detailBackgroundAlpha)
end

function ns.SetHUDBorderStyle(value)
    if value ~= "transparent" and value ~= "class" and value ~= "gold" then
        value = DEFAULTS.borderStyle
    end
    GetDB().borderStyle = value
end

-- Window look. "auto" follows EllesmereUI's own Style page; "blizzard" and
-- "classic" pin the native shells (EUINative.lua); "addon" pins the addon's
-- own flat style. The look is applied when frames are built, so a change
-- takes effect after a UI reload.
function ns.GetAppearanceMode()
    return GetDB().appearance or DEFAULTS.appearance
end

function ns.SetAppearanceMode(value)
    if value ~= "addon" and value ~= "blizzard" and value ~= "classic" then
        value = DEFAULTS.appearance
    end
    GetDB().appearance = value
end

function ns.SetRowVisible(key, value)
    if DEFAULT_ROW_VISIBILITY[key] ~= nil then
        GetDB().showRows[key] = value == true
        if ns.RefreshMeetingStoneIntegration then
            ns.RefreshMeetingStoneIntegration("profile")
        end
    end
end

function ns.GetHUDVisualSettings()
    local db = GetDB()
    local r, g, b, a = GetHUDAccentColor()
    return {
        borderStyle = db.borderStyle,
        borderR = r,
        borderG = g,
        borderB = b,
        borderAlpha = a,
        backgroundAlpha = db.backgroundAlpha,
    }
end

function ns.GetDetailVisualSettings()
    local db = GetDB()
    local r, g, b, a = GetDetailAccentColor()
    return {
        borderStyle = db.borderStyle,
        borderR = r,
        borderG = g,
        borderB = b,
        borderAlpha = a,
        backgroundAlpha = db.detailBackgroundAlpha,
    }
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("CHALLENGE_MODE_COMPLETED")
eventFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= ADDON_NAME then
            return
        end
        self:UnregisterEvent("ADDON_LOADED")
        InitializeDatabase()
        ns.ResolveSelectedRegion()
        if not englishTextWarningPrinted
            and CLIENT_LOCALE ~= "zhCN"
            and CLIENT_LOCALE ~= "zhTW"
            and (L.SCORE ~= "M+ Score"
                or L.DETAIL_COLUMN_NAME ~= "Dungeon"
                or L.VAULT_RAID ~= "Raid")
        then
            englishTextWarningPrinted = true
            print(L.ADDON_TITLE .. ": English UI text was overwritten by another addon or an outdated build.")
        end
        if ns.InitializeSettings then
            ns.InitializeSettings()
        end
        local API = _G.QFXMythicRankData
        if API and type(API.RegisterCallback) == "function" then
            API:RegisterCallback(ns, function(_, region)
                local selectedRegion = ns.GetSelectedRegion() or ns.ResolveSelectedRegion()
                if ns.RefreshRegionSelector then
                    ns.RefreshRegionSelector()
                end
                if region == selectedRegion then
                    if ns.RefreshMeetingStoneIntegration then
                        ns.RefreshMeetingStoneIntegration("profile")
                    end
                end
            end)
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        UpdateDailyScoreStateOnly()
        if ns.HandleMythicDetailEvent then
            ns.HandleMythicDetailEvent(event, arg1)
        end
    elseif event == "CHALLENGE_MODE_COMPLETED" then
        if C_Timer and type(C_Timer.After) == "function" then
            C_Timer.After(2, function()
                UpdateDailyScoreStateOnly()
            end)
        else
            UpdateDailyScoreStateOnly()
        end
        if ns.HandleMythicDetailEvent then
            ns.HandleMythicDetailEvent(event, arg1)
        end
    end
end)
